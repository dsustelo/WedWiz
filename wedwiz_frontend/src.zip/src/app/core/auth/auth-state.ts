import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export type UserRole = 'guest' | 'organizer' | 'admin';

@Injectable({
  providedIn: 'root',
})
export class AuthState {
  private _isLoggedIn = new BehaviorSubject<boolean>(false);
  private _role = new BehaviorSubject<UserRole>('guest');

  // Observables que os componentes vão usar
  isLoggedIn$ = this._isLoggedIn.asObservable();
  role$ = this._role.asObservable();

  // Métodos para alterar o estado (por agora, "fake")
  login(role: UserRole = 'organizer') {
    this._isLoggedIn.next(true);
    this._role.next(role);
  }

  logout() {
    this._isLoggedIn.next(false);
    this._role.next('guest');
  }
}
