import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { HeaderButton } from '../header-button/header-button';
import { Observable } from 'rxjs';
import { AuthState, UserRole } from '../../../app/core/auth/auth-state';

@Component({
  selector: 'app-header',
  imports: [CommonModule, RouterModule, HeaderButton],
  templateUrl: './header.html',
  styleUrl: './header.scss',
})
export class Header {
  isLoggedIn$: Observable<boolean>;
  role$: Observable<UserRole>;

  constructor(private authState: AuthState) {
    this.isLoggedIn$ = this.authState.isLoggedIn$;
    this.role$ = this.authState.role$;
  }

  // Por agora: login "fake" só para ver o header a mudar
  loginAsOrganizer() {
    this.authState.login('organizer');
  }

  loginAsAdmin() {
    this.authState.login('admin');
  }

  logout() {
    this.authState.logout();
  }
}
